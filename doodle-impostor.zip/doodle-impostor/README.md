# 🕵️ Doodle Impostor

A party drawing game for phones. Everyone gets the same secret word, except the
**impostor**, who only sees the category. Players take turns drawing something
*related* to the word in 30 seconds while everyone watches the drawing appear
live. Then the group votes on who the impostor is.

One phone hosts, everyone else joins with a room code or QR code. No app, no
computer, no server. The whole game is the single file `index.html`.

## Put it online (GitHub Pages, about 5 minutes)

1. In GitHub, create a new **public** repository (for example `Doodle-Impostor`).
2. Upload `index.html` to it (Add file → Upload files → Commit).
3. Go to **Settings → Pages**. Under "Build and deployment", choose
   **Deploy from a branch**, branch `main`, folder `/ (root)`, and tap **Save**.
4. After a minute or two, the game is at
   `https://<your-username>.github.io/Doodle-Impostor/`.

It works the same on Vercel or any other static host.

## How to play

1. The host opens the page and taps **Host a game**. A room code and QR code appear.
2. Friends scan the QR code or open the page and type the code. Any network works,
   Wi-Fi or mobile data.
3. With 3 or more players, the host taps **Start game**.
4. Everyone **presses and holds** the dark card to see their secret privately, then taps **I'm ready**.
5. Players draw one at a time, in a random order. The impostor never goes first.
   Everyone watches each drawing live, and earlier drawings stay in the
   "Drawings so far" strip.
6. **😈 Sabotage** (on by default, 4+ players): one crew player is secretly the **saboteur**.
   The saboteur and the impostor can each sneak onto ONE other player's drawing while it's
   being made: tap **🎭 Secret action**, then pick **Add something** *or* **Erase something**
   (one or the other). They get 8 seconds and a small amount of ink. Everyone has the
   🎭 button, so having it gives nothing away, and only one sabotage can hit each drawing.
7. **🔒 Impostor takeover** (optional, off by default, 4+ players): once per round the impostor
   can use **🎭 Secret action** to grab another player's upcoming turn. When that turn comes,
   the impostor secretly draws it, everyone else sees the usual "Leo is drawing…", and Leo's
   phone says he's locked out for that one drawing. Leo can speak up, but can he prove it?
8. After the last turn, talk it over and vote on three things: who's the **impostor**, who's
   the **saboteur**, and whose drawing fit the word **best ⭐**. A tie for impostor gets one
   revote between the tied players.
9. If the impostor is caught, they pick the secret word from 8 choices to try to steal the win.
   The results show who sabotaged which drawing (with before and after pictures) and which turn
   the impostor took over.

**Tip:** an extra tablet, laptop or smart TV browser can join as a **big screen**
(on the join page). It shows the live drawings large and never shows anyone's word.

## Scoring

| What happened | Points |
|---|---|
| You voted for the impostor | +1 |
| You voted for the saboteur | +1 |
| Crew wins (impostor caught and guessed wrong) | +1 to every crew player |
| Impostor caught but guessed the word | Impostor +1 |
| Impostor not voted out | Impostor +3 |
| Saboteur sabotaged a drawing and wasn't voted out | Saboteur +2 |
| Most ⭐ best-drawing votes (ties all count) | +1 to whoever really drew it |

## Settings (host, in the lobby)

- **Words / game mode:**
  - 🎨 Normal (classic): the original game, all 10 everyday categories. This is the default.
  - 🎲 Mix of everything: Normal plus Easy, Kids and Hard words (never 18+)
  - 🟢 Easy: simple words (cat, sun, pizza…)
  - 🧸 Kids: toys, pretend play and animal friends
  - 🔴 Hard: tricky ideas (nostalgia, gravity, inflation, plot twist…)
  - 🔞 After Dark (18+): night out, dating and party-game words, cheeky but not explicit
  - any one of 10 categories (animals, food, house, places, jobs, sports, nature,
    things that move, clothes, spooky & fantasy), or ✏️ My own words
- **Sabotage:** on or off. The saboteur role needs 4 or more players; with 3 players nobody sabotages,
  since any sabotage would give the impostor away.
- **Impostor takeover:** on or off (off by default). Needs 4 or more players.
- **Twist:**
  - 🎨 Normal: no twist
  - 🙈 Blind drawing: you can't see your own drawing
  - ✍️ One line only: your turn ends when you lift your finger
  - ⚡ Speed: 15 seconds to draw
  - 🔀 Secret swap: everyone secretly draws for someone else, so drawings show up under the
    wrong names. Your secret card tells you who you're drawing for. Bluff, accuse, and see
    "who really drew what" in the results.
  - 🎲 Random: cycles through all of the above, Normal included, so every twist comes up once
    before any repeats.
- **Draw time:** 20, 30 (default), 45 or 60 seconds.
- **Turns each:** Auto (2 turns each with 5 or fewer players, otherwise 1), 1, or 2.
- **Rounds:** 3, 5, 8 or endless.
- **Impostor sees category:** on by default. Turn it off for a harder game.
- **Language:** English or Español. Words and every screen switch for all players.

## Drawing tools

Pen, paint bucket, eraser, undo and clear, with 16 colors and 4 brush sizes.
**Done ✓** ends your turn early.

## Good to know

- **Every phone needs internet.** Messages go through free public MQTT relay services
  (HiveMQ, EMQX and Mosquitto), with automatic fallback if one is down. Names and
  drawings pass through them, so it's fine for a party game but not for private information.
- **Keep the host's screen open.** The page asks the phone to stay awake. If the host's
  phone locks or reloads, the game picks up where it left off when the page is opened again.
  Players who reload rejoin automatically, and a player who reloads mid-drawing keeps their drawing.
- People who join mid-round watch that round and play from the next one.
- The host can remove players (✕ in the lobby) and use the ☰ menu to skip a turn,
  skip a round, or end the game.
- Up to 12 players.
